from django.shortcuts import render,redirect
from django.http import HttpResponse
from food.models import User,Booking,Feedback,Menu
import re


def main(request):
    return render(request,'index.html')
def home(request):
    return render(request, 'index.html')
def home_2(request):
    menu_view = Menu.objects.all()
    return render(request, 'index_2.html', {"UM": menu_view})
def home_3(request):
    menu_view = Menu.objects.all()
    return render(request, 'menu_2.html', {"UM": menu_view})

def about(request):
    menu_view = Menu.objects.all()
    return render(request, 'about.html', {"UM": menu_view})
def contact(request):
    return render(request,'contact.html')
def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'register.html')
def gallery(request):
    return render(request,'gallery.html')
def admin_home(request):
    return render(request,'admin_home.html')
def price(request):
    return render(request,'price.html')
def photos(request):
    return render(request,'photos.html')
def addmenu(request):
    return render(request,'addmenu.html')
def login(request):
    return render(request,'login.html')
def reservation(request):
    return render(request,'reservation.html')

def home_4(request):
    menu_view = Menu.objects.all()
    return render(request, 'home_4.html', {"UM": menu_view})


def menu(request):
    menu_view = Menu.objects.all()
    return render(request, 'menu.html', {"UM": menu_view})

def bookings(request):
    dt=Booking.objects.all()
    return render(request,'bookings.html',{"id":dt})

def cart(request):

    uid = request.session['user']
    mail = User.objects.get(email=uid)

    data=Booking.objects.filter(email=mail)
    if data:
        return render(request,'cart.html',{"cart":data})
    else:
        return render(request, 'index_2.html',{'alert_flag':True})



def User_save(request):
    b = request.POST['username']
    c = request.POST['age']
    d = request.POST['gender']
    e = request.POST['number']
    f = request.POST['email']
    g = request.POST['password']
    h=request.POST['password1']
    if re.match(r"^[6789]{1}\d{9}$", e):
        if re.match(r'[\w-]{1,20}@\w{2,20}\.\w{2,3}$', f):
            if g==h:
                data=User(username=b,age=c,gender=d,phone=e,email=f,password=g,type=1)
                data.save()
                return render(request, 'index.html')
            else:
                return render(request,'register.html')
        else:
            return render(request,"register.html",{"valid":'!!!Invalid EmailAddress!!!'})
    else:
        return render(request, "register.html", {"valid": '!!!Invalid EmailAddress!!!'})




def reserv_data(request):
    db=Booking.objects.all().last()
    idb =db.bkid+1
    a= request.POST['name']
    n= request.POST['nop']
    p=request.POST['phone']
    e1 = request.session['user']
    e=User.objects.get(email=e1)
    d = request.POST['date']
    m=request.POST['email']

    data=Booking(bkid=idb,name=a,nop=n,email=e,optmail=m,phone=p,date=d)
    data.save()
    return render(request,'index_2.html')





def editmenu(request):
    fid = request.POST['fid']
    fn=request.POST['food']
    rs = request.POST['price']
    cat=request.POST['cate']
    dis=request.POST['dis']
    data=Menu.objects.filter(foodid=fid).update(foodname=fn,foodcatogory=cat,fooddiscription=dis,fprice=rs)
    data.save()
    return render(request,'editmenu.html')


def updatemenu(request):
    data=Menu.objects.all()
    return render(request,'updatemenu.html',{"UM":data})



def add_food(request):

    fid=request.POST['fid']
    name = request.POST['food']
    rs = request.POST['price']
    cat=request.POST['cate']
    dis=request.POST['dis']
    pic=request.FILES['img']

    hate = Menu(foodid=fid,foodcatogory=cat,foodname=name,fooddiscription=dis,fprice=rs,pic=pic)
    hate.save()
    return render(request,'addmenu.html')


def edit_menu(request):
    a=request.POST['fid']
    print(a)
    user=Menu.objects.filter(foodid=a)
    return render(request,'edit_update.html',{"user":user})

def Editing(request):
    fid = request.POST['fid']
    fn = request.POST['fname']
    rs = request.POST['frs']
    cat = request.POST['fcate']
    dis = request.POST['fdis']
    if request.FILES:

        img=request.FILES['pic']
        data = Menu.objects.get(foodid=fid)
        data.foodid=fid
        data.foodname=fn
        data.foodcatogory=cat
        data. fooddiscription=dis
        data.fprice=rs
        data.pic=img
        data.save()
        return redirect(updatemenu)
    else:
        Menu.objects.filter(foodid=fid).update(foodname=fn, foodcatogory=cat, fooddiscription=dis, fprice=rs)
        return redirect(updatemenu)


def delete_menu(request):
    de=request.POST['fid']
    Menu.objects.filter(foodid=de).delete()
    return redirect(updatemenu)




def search(request):
    userlist=User.objects.all()
    return render(request,'display.html',{"ul":userlist})




def userlist(request):
    userlist = User.objects.filter(type=1)
    return render(request,'userlist.html',{'ue':userlist})




def feedb(request):
    uid=request.session['user']
    u=User.objects.get(email=uid)
    s=request.POST['subject']
    m = request.POST['message']
    data=Feedback(userid=u,subject=s,message=m)
    data.save()
    return render(request,'contact.html')








def cartED(request):
    us = request.session['user']
    usid = User.objects.get(email=us)

    bkid=int(request.POST['bkid'])
    data=Booking.objects.filter(email=usid)
    for user in data:
        if user.bkid == bkid:


            return render(request,'editcart.html',{'e':user})



def cartedit(request):
    a=request.POST['user']
    b=request.POST['date']
    c=request.POST['nop']
    op=request.POST['mail']
    ef=request.session['user']
    bid=request.POST['bkid']
    e=User.objects.get(email=ef)
    d=request.POST['number']
    Booking.objects.filter(bkid=bid).update(email=e,optmail=op,date=b,name=a,nop=c,phone=d)

    return redirect(cart)

def delete(request):
    de=int(request.POST['bkid'])
    Booking.objects.filter(bkid=de).delete()
    return redirect(cart)

def feedback(request):
    feedb= Feedback.objects.all()
    return render(request,'feedback.html',{"users":feedb})


def delete_menu(request):
        d = request.POST['fid']
        Menu.objects.filter(foodid=d).delete()
        return redirect(updatemenu)




def reservation_data(request):
    e = request.POST['email']
    d = request.POST['date']
    data=User.objects.get(email=d)
    if data.email==e :
        request.session['user'] = d
        return HttpResponse("registration Successful")
    else:
        return HttpResponse("Your connection error...")







def loginn(request):
    userid = request.POST['emailid']
    pwd = request.POST['password']
    try:
        data=User.objects.get(email=userid)
        if data.password == pwd and data.type == 1:
            request.session['user'] = userid
            return render(request,'index_2.html')
        elif data.password == pwd and data.type == 0:
            request.session['user'] = userid
            return render(request,'admin_home.html')
        else:
            return render(request, 'login.html',{'alert_flag':True})
    except:
        return render(request, 'login.html',{'alert_flag':True})

def menu_2(request):
    menu_view = Menu.objects.all()
    return render(request,'menu_2.html',{"UM": menu_view})


        #return render(request,'login.html')



# Create your views here.
