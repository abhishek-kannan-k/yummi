from django.db import models
class User(models.Model):
    username = models.CharField(max_length=20)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    phone = models.IntegerField()
    email = models.CharField(max_length=20)
    password = models.CharField(max_length=10)
    type = models.IntegerField()
    def __str__(self):
        return self.email


class Menu(models.Model):
    foodid = models.IntegerField(primary_key=True)
    foodcatogory = models.CharField(max_length=20)
    foodname = models.CharField(max_length=20)
    fooddiscription = models.CharField(max_length=100)
    fprice = models.CharField(max_length=10)
    pic = models.FileField()



class Booking(models.Model):
    bkid=models.IntegerField()
    name = models.CharField(max_length=20)
    email=models.ForeignKey(User,on_delete=models.CASCADE)
    optmail=models.CharField(max_length=50)
    date = models.CharField(max_length=30)
    nop=models.IntegerField()
    phone = models.IntegerField()


class Feedback(models.Model):
    userid=models.ForeignKey(User,on_delete=models.CASCADE)
    subject=models.CharField(max_length=50)
    message=models.CharField(max_length=200)


    # Create your models here.:

