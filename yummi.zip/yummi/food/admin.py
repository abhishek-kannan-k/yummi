from django.contrib import admin
from food.models import User
from food.models import Menu
from food.models import Feedback
from .models import Booking


admin.site.register(User)
admin.site.register(Menu)
admin.site.register(Feedback)
admin.site.register(Booking)

# Register your models here.
